Node *temp = head;
    head = tail;
    tail = temp;