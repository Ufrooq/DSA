         cout << "333333333333";
            cout << st.checkPalindrome() ? "Palindrome" : "Not a Palindrome";
        