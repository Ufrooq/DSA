#include <iostream>
using namespace std;

class
{
public:
    char array;
};

int main()
{
    return 0;
};